CREATE DATABASE IF NOT EXISTS hotel;
USE hotel;

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(45) DEFAULT NULL,
  `app` varchar(45) DEFAULT NULL,
  `apm` varchar(45) DEFAULT NULL,
  `dni` int(8) DEFAULT NULL,
  `ruc` varchar(11) DEFAULT NULL,
  `razonSocial` varchar(45) DEFAULT NULL,
  `celular` varchar(9) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `detallereserva`;
CREATE TABLE `detallereserva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idReserva` int(11) NOT NULL,
  `idHabitacion` int(11) NOT NULL,
  `subTotalDescuento` decimal(8,2) NOT NULL,
  `subTotalPrecio` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reserva_has_habitacion1_idx` (`idHabitacion`),
  KEY `fk_reserva_has_reserva1_idx` (`idReserva`),
  CONSTRAINT `fk_reserva_has_habitacion1` FOREIGN KEY (`idHabitacion`) REFERENCES `habitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reserva_has_reserva1` FOREIGN KEY (`idReserva`) REFERENCES `reserva` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `habitacion`;
CREATE TABLE `habitacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `idTipoHabitacion` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_habitacion_tipo_idx` (`idTipoHabitacion`),
  CONSTRAINT `fk_habitacion_tipo` FOREIGN KEY (`idTipoHabitacion`) REFERENCES `tipohabitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `promocion`;
CREATE TABLE `promocion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  `descuento` int(11) NOT NULL,
  `idTipoPromocion` int(11) NOT NULL,
  `fechaInicio` date NOT NULL,
  `fechaFin` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_promocion_tipoPromocion1_idx` (`idTipoPromocion`),
  CONSTRAINT `fk_promocion_tipoPromocion1` FOREIGN KEY (`idTipoPromocion`) REFERENCES `tipopromocion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `reserva`;
CREATE TABLE `reserva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `estado` varchar(45) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `fechaIncio` date NOT NULL,
  `fechaFin` date NOT NULL,
  `idPromocion` int(11) DEFAULT NULL,
  `totalDescuento` decimal(8,2) NOT NULL,
  `totalPrecio` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reserva_cliente1_idx` (`idCliente`),
  KEY `fk_reserva_promocion1_idx` (`idPromocion`),
  CONSTRAINT `fk_reserva_cliente1` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reserva_promocion1` FOREIGN KEY (`idPromocion`) REFERENCES `promocion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `tipohabitacion`;
CREATE TABLE `tipohabitacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `vista` varchar(45) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(8,2) NOT NULL,
  `imagen` varchar(45) NOT NULL,
  `tamanio` varchar(45) NOT NULL,
  `cantPersonas` int(11) NOT NULL,
  `numCamas` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `tipopromocion`;
CREATE TABLE `tipopromocion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
