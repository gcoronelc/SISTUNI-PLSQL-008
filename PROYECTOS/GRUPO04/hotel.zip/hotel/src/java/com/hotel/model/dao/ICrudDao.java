
package com.hotel.model.dao;

import java.util.List;

public interface ICrudDao<Entity> {
    List<Entity> readAll() throws Exception;
    boolean create(Entity a) throws Exception;
    boolean update(Entity a) throws Exception;
    boolean delete(int id) throws Exception;
    Entity find(int id) throws Exception;
}