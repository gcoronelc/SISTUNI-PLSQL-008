package com.hotel.conection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    Connection con;
    public static final String USER = "hotel";
    public static final String PASSWORD = "admin";
    public static final String DATABASE = "hotel";
    public static final String URL = "jdbc:oracle:thin:@127.0.0.1:1521/orcl";
    //static String url = "jdbc:oracle:thin:@172.17.0.180:1521:XE";
    
    public Conexion() throws SQLException {        
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            this.con = (Connection) DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Error de conexion: " + ex.getMessage());
        }        
    }

    public Connection getConexion() throws SQLException{
        return con;
    }
    
    public static void main(String[] args) {
        try {
            Conexion con = new Conexion();
        } catch (SQLException ex) {
            System.err.println("Error de conexion: " + ex.getMessage());
        }
    }
}

/*
package com.hotel.conection;
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    Connection con;
    public static final String USER = "root";
    public static final String PASSWORD = "";
    public static final String DATABASE = "hotel";
    public static final String URL = "jdbc:mysql://localhost:3306/"+DATABASE;

    public Conexion() {        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.con = (Connection) DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
            System.err.println("Error de conexion: " + ex.getMessage());
        }        
    }

    public Connection getConexion() throws SQLException{
        return con;
    }
    
    public static void main(String[] args) {
        Conexion con = new Conexion();
    }
}
*/