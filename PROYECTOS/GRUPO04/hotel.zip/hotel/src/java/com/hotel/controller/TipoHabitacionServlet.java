package com.hotel.controller;

import com.hotel.model.TipoHabitacion;
import com.hotel.model.impl.TipoHabitacionDaoImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "TipoHabitacionServlet", urlPatterns = {"/TipoHabitacion"})
public class TipoHabitacionServlet extends HttpServlet {
    
    RequestDispatcher vista;
    String login = "view/tipo_habitacion/login.jsp";
    String listar = "view/tipo_habitacion/rooms.jsp";
    String detalle = "view/tipo_habitacion/room.jsp";
    String nuevo = "view/tipo_habitacion/nuevo.jsp";
    String editar = "view/tipo_habitacion/editar.jsp";
    String acceso;
    TipoHabitacion oTipHab;
    String path;
    String context;
    HttpSession session;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        System.out.println(accion);

        switch (accion) {
                    case "listar":
                        listar(request, response);
                        break;
                    case "detalle":
                        detalle(request, response);
                        break;    
                }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void listar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            acceso = listar;
            TipoHabitacionDaoImpl tipHabDao = new TipoHabitacionDaoImpl();
            List<TipoHabitacion> ListaTipHab = tipHabDao.readAll();
            request.setAttribute("ListaTipHab", ListaTipHab);
            vista = request.getRequestDispatcher(acceso);
            vista.forward(request, response);
        } catch (Exception ex) {
            System.err.println("Error de logeo: " + ex.getMessage());
        }
    }
    
    private void detalle(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        TipoHabitacionDaoImpl tipHabDao = new TipoHabitacionDaoImpl();
        try {
            TipoHabitacion oTipHab = tipHabDao.find(id);
            request.setAttribute("oTipHab", oTipHab);
        } catch (Exception ex) {
            System.out.println("error de nuevo:" + ex.getMessage());
        }

        acceso = detalle;
        vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }
}
