/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hotel.model.impl;

import com.hotel.conection.Conexion;
import com.hotel.model.TipoHabitacion;
import com.hotel.model.dao.ICrudDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author JWeb-MJ
 */
public class TipoHabitacionDaoImpl implements ICrudDao<TipoHabitacion>{

    Conexion cn;
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    TipoHabitacion tipHab;
    String sql;
    
    @Override
    public List<TipoHabitacion> readAll() throws Exception {
        List<TipoHabitacion> TipoHabitaciones = new ArrayList<>();
        try {
            sql = "SELECT * FROM HOTEL.tipohabitacion";
            cn = new Conexion();
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();        
            tipHab = null;
            while (rs.next()) {            
                tipHab = new TipoHabitacion();
                tipHab.setId(rs.getInt("id"));
                tipHab.setNombre(rs.getString("nombre"));
                tipHab.setVista(rs.getString("vista"));
                tipHab.setDescripcion(rs.getString("descripcion"));
                tipHab.setPrecio(rs.getDouble("precio"));
                tipHab.setImagen(rs.getString("imagen"));
                tipHab.setTamanio(rs.getString("tamanio"));
                tipHab.setCantPersonas(rs.getInt("cantPersonas"));
                tipHab.setNumCamas(rs.getInt("numCamas"));
                TipoHabitaciones.add(tipHab);
            }
            rs.close();
            ps.close();            
        } catch (SQLException ex) {
            System.err.println("Error de query: "  + ps.toString() + ex.getMessage());
        }finally{
            con.close();
        }
        
        return TipoHabitaciones;
    }

    @Override
    public boolean create(TipoHabitacion a) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean update(TipoHabitacion a) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TipoHabitacion find(int id) throws Exception {
        
        try {
            sql = "SELECT * FROM HOTEL.tipohabitacion WHERE id = ? ";
            cn = new Conexion();
            con = cn.getConexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();        
            tipHab = null;
            tipHab = new TipoHabitacion();
            if (rs.next()) {
                tipHab.setId(rs.getInt("id"));
                tipHab.setNombre(rs.getString("nombre"));
                tipHab.setVista(rs.getString("vista"));
                tipHab.setDescripcion(rs.getString("descripcion"));
                tipHab.setPrecio(rs.getDouble("precio"));
                tipHab.setImagen(rs.getString("imagen"));
                tipHab.setTamanio(rs.getString("tamanio"));
                tipHab.setCantPersonas(rs.getInt("cantPersonas"));
                tipHab.setNumCamas(rs.getInt("numCamas"));               
            }
            rs.close();
            ps.close();            
        } catch (SQLException ex) {
            System.err.println("Error de query: "  + ps.toString() + ex.getMessage());
        }finally{
            con.close();
        }
        
        return tipHab;
    }
    
    public static void main(String[] args) {
        TipoHabitacionDaoImpl dao = new TipoHabitacionDaoImpl();
        TipoHabitacion tipHab = new TipoHabitacion();
        try {
            tipHab = dao.find(1);
            System.out.println(tipHab.toString());
        } catch (Exception ex) {
            Logger.getLogger(TipoHabitacionDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
