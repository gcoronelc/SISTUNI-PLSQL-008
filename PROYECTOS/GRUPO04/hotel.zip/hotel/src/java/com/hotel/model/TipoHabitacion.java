package com.hotel.model;

public class TipoHabitacion {
    private int id;
    private String nombre;
    private String vista;
    private String descripcion;
    private double precio;
    private String imagen;
    private String tamanio;
    private int cantPersonas;
    private int numCamas;

    public TipoHabitacion() {
    }

    public TipoHabitacion(int id, String nombre, String vista, String descripcion, double precio, String imagen, String tamanio, int cantPersonas, int numCamas) {
        this.id = id;
        this.nombre = nombre;
        this.vista = vista;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        this.tamanio = tamanio;
        this.cantPersonas = cantPersonas;
        this.numCamas = numCamas;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getVista() {
        return vista;
    }

    public void setVista(String vista) {
        this.vista = vista;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }

    public int getCantPersonas() {
        return cantPersonas;
    }

    public void setCantPersonas(int cantPersonas) {
        this.cantPersonas = cantPersonas;
    }

    public int getNumCamas() {
        return numCamas;
    }

    public void setNumCamas(int numCamas) {
        this.numCamas = numCamas;
    }

    @Override
    public String toString() {
        return "TipoHabitacion{" + "id=" + id + ", nombre=" + nombre + ", vista=" + vista + ", descripcion=" + descripcion + ", precio=" + precio + ", imagen=" + imagen + ", tamanio=" + tamanio + ", cantPersonas=" + cantPersonas + ", numCamas=" + numCamas + '}';
    }
    
}
